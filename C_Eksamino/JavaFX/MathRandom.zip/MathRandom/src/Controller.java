import java.util.Random;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private Button btnNum1;

    @FXML
    private Button btnOperator;

    @FXML
    private Button btnNum2;

    @FXML
    private TextField answerField;

    @FXML
    private Label resultLabel;

    private int num1;
    private int num2;
    private String operator;
    private int correctAnswer;
    private Random random = new Random();

    public void initialize() {
        generateNewQuestion();
    }

    @FXML
    private void generateNewQuestion() {
        num1 = random.nextInt(10) + 1;
        num2 = random.nextInt(10) + 1;

        String[] operators = {"+", "-", "*"};
        operator = operators[random.nextInt(operators.length)];

        switch (operator) {
            case "+":
                correctAnswer = num1 + num2;
                break;
            case "-":
                correctAnswer = num1 - num2;
                break;
            case "*":
                correctAnswer = num1 * num2;
                break;
        }

        btnNum1.setText(String.valueOf(num1));
        btnOperator.setText(operator);
        btnNum2.setText(String.valueOf(num2));

        answerField.clear();
        resultLabel.setText("");
    }

    @FXML
    private void checkAnswer() {
        try {
            // Μετατροπή του κειμένου που έγραψε ο χρήστης σε ακέραιο αριθμό
            int userAnswer = Integer.parseInt(answerField.getText().trim());

            if (userAnswer == correctAnswer) {
                resultLabel.setText("Σωστό! Μπράβο!");
                resultLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
            } else {
                resultLabel.setText("Λάθος! Το σωστό είναι: " + correctAnswer);
                resultLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
            }
        } catch (NumberFormatException e) {
            // Αν ο χρήστης πατήσει Έλεγχο χωρίς να έχει γράψει έγκυρο αριθμό
            resultLabel.setText("Παρακαλώ γράψε έναν έγκυρο αριθμό!");
            resultLabel.setStyle("-fx-text-fill: orange;");
        }
    }
}